# ProgressiveFocus

Slows down time when shooting. 
Is enabled by holding down one of the triggers completely and then pressing the second one down slowly.
The second trigger can be either your shooting hand or offhand. Try playing around to get a feel for this.
 
The time is being slowed down as far as you press the second trigger. 
AKA -> press trigger down 50% -> time slowed down 50%.
AKA -> press trigger down 70% -> time slowed down 70%.

Cuts of at 5% of normal time scale.

# Changelog:
## 1.0.2:
- Fixed sound pitch 
- Adjusted lowest timescale allowed